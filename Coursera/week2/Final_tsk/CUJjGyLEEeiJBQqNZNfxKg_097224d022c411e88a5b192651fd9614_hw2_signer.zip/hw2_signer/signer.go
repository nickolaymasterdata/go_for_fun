package main

// сюда писать код